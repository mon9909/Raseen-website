
const translations = {
  en: {
    home:"Home", about:"About", services:"Services", investment:"Investment", risk:"Risk", markets:"Sectors",
    insights:"Insights", experts:"Expert Network", contact:"Contact", lang:"AR",
    cta:"Request a Conversation"
  },
  ar: {
    home:"الرئيسية", about:"من نحن", services:"الخدمات", investment:"الاستثمار", risk:"تقييم المخاطر", markets:"القطاعات",
    insights:"الرؤى", experts:"شبكة الخبراء", contact:"تواصل", lang:"EN",
    cta:"طلب استشارة"
  }
};
function setLang(lang){
  document.documentElement.lang=lang;
  document.documentElement.dir=lang==="ar"?"rtl":"ltr";
  document.querySelectorAll("[data-i18n]").forEach(el=>{
    const key=el.dataset.i18n;
    if(translations[lang][key]) el.textContent=translations[lang][key];
  });
  localStorage.setItem("raseen-lang",lang);
}
function toggleLang(){ setLang((localStorage.getItem("raseen-lang")||"en")==="en"?"ar":"en"); }
document.addEventListener("DOMContentLoaded",()=>{
  const lang=localStorage.getItem("raseen-lang")||"en"; setLang(lang);
  document.querySelectorAll("[data-menu]").forEach(btn=>{
    btn.addEventListener("click",()=>document.querySelector(".navlinks").classList.toggle("open"));
  });
  document.querySelectorAll("form[data-demo-form]").forEach(form=>{
    form.addEventListener("submit",e=>{
      e.preventDefault();
      const note=document.createElement("div");
      note.className="form-success";
      note.style="margin-top:16px;padding:15px;border:1px solid #b99770;background:#f5f0e8;color:#22313c;font-size:13px";
      note.textContent=document.documentElement.lang==="ar"?"تم استلام طلبك مبدئياً. اربط النموذج لاحقاً بالبريد أو نظام إدارة الطلبات.":"Your request has been captured as a demo. Connect this form to your email or CRM before launch.";
      form.appendChild(note);
      form.reset();
    });
  });
});
