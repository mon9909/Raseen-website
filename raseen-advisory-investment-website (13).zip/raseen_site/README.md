# RASEEN Advisory & Investment — website starter

A responsive, multi-page static website starter with English/Arabic language switching. The brand name RASEEN is provisional until legal and trademark checks are complete.

## Pages
- `index.html` — Home
- `pages/about.html` — About
- `pages/services.html` — Services
- `pages/investment.html` — Investment advisory
- `pages/risk.html` — Risk assessment
- `pages/markets.html` — Sector perspectives (not a list of countries)
- `pages/expert-network.html` — Expert network model
- `pages/insights.html` — Insights
- `pages/contact.html` — Request form

## Before launch
1. Verify/reserve the trade name and check trademark rights. Official Saudi trade-name reservation guidance: https://mc.gov.sa/en/eservices/Pages/ServiceDetails.aspx?sID=1
2. Replace any sample claims, sectors, or service descriptions with verified company facts. Do not add clients, completed mandates, credentials or testimonials without permission and evidence.
3. Connect the request form to a secure form endpoint or CRM. It currently demonstrates a front-end submission only and does not send email.
4. Add a privacy notice and data-retention policy before collecting real enquiries.
5. Confirm any required licenses before offering regulated financial or investment services.

The site includes general-information disclaimers. It is not legal advice.
